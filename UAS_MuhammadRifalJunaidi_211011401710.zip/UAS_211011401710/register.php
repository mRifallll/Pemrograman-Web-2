<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password']; // Enkripsi password

    // Query untuk menambahkan user baru ke dalam database
    $sql = "INSERT INTO users (nim, password ) VALUES ('$username', '$password' )";

    if ($conn->query($sql) === TRUE) {
        echo "Registrasi berhasil!";
        header('location: login.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<h2>Registrasi</h2>
<form method="post">
    <label>Username:</label><br>
    <input type="text" name="username" required><br><br>

    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>

    <input type="submit" value="Daftar"> <br>

    <a href="login.php">Kembali Ke halaman login</a>
</form>