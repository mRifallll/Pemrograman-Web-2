<?php
require('fpdf186/fpdf.php');
include 'config.php';

$countries = $conn->query("SELECT * FROM countries");

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'UEFA 2024 Standings', 1, 1, 'C');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 10, 'Group', 1);
$pdf->Cell(30, 10, 'Country', 1);
$pdf->Cell(20, 10, 'Wins', 1);
$pdf->Cell(20, 10, 'Draws', 1);
$pdf->Cell(20, 10, 'Losses', 1);
$pdf->Cell(20, 10, 'Points', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
while ($country = $countries->fetch_assoc()) {
    $pdf->Cell(30, 10, $country['group_id'], 1);
    $pdf->Cell(30, 10, $country['name'], 1);
    $pdf->Cell(20, 10, $country['wins'], 1);
    $pdf->Cell(20, 10, $country['draws'], 1);
    $pdf->Cell(20, 10, $country['losses'], 1);
    $pdf->Cell(20, 10, $country['points'], 1);
    $pdf->Ln();
}

$pdf->Output();
