<?php
session_start();
ob_start();
if (!isset($_SESSION['nim'])) {
    header("Location: login.php");
    exit();
}
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_country'])) {
    $group_id = $_POST['group_id'];
    $name = $_POST['name'];
    $wins = $_POST['wins'];
    $draws = $_POST['draws'];
    $losses = $_POST['losses'];
    $points = $_POST['points'];

    $query = $conn->prepare("INSERT INTO countries (group_id, name, wins, draws, losses, points) VALUES (?, ?, ?, ?, ?, ?)");
    $query->bind_param('isiiii', $group_id, $name, $wins, $draws, $losses, $points);
    $query->execute();
}

$groups = $conn->query("SELECT * FROM groups");
$countries = $conn->query("SELECT * FROM countries");

?>

<form method="post">
    Group:
    <select name="group_id">
        <?php while ($group = $groups->fetch_assoc()) { ?>
            <option value="<?= $group['id'] ?>"><?= $group['name'] ?></option>
        <?php } ?>
    </select><br>
    Country:
    <select name="name">
        <!-- Add country options manually or from another table if available -->
        <option value="Germany">Germany</option>
        <option value="Switzerland">Switzerland</option>
        <option value="Hungary">Hungary</option>
        <option value="Scotland">Scotland</option>
        <!-- Add other countries as needed -->
    </select><br>
    Wins: <input type="number" name="wins" required><br>
    Draws: <input type="number" name="draws" required><br>
    Losses: <input type="number" name="losses" required><br>
    Points: <input type="number" name="points" required><br>
    <input type="submit" name="add_country" value="Add Country">
</form>

<table border="1">
    <tr>
        <th>Group</th>
        <th>Country</th>
        <th>Wins</th>
        <th>Draws</th>
        <th>Losses</th>
        <th>Points</th>
    </tr>
    <?php while ($country = $countries->fetch_assoc()) { ?>
        <tr>
            <td><?= $country['group_id'] ?></td>
            <td><?= $country['name'] ?></td>
            <td><?= $country['wins'] ?></td>
            <td><?= $country['draws'] ?></td>
            <td><?= $country['losses'] ?></td>
            <td><?= $country['points'] ?></td>
        </tr>
    <?php } ?>
</table>